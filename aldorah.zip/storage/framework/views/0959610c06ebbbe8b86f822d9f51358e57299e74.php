<?php $__env->startSection('title' , 'Admin Panel Add New Product'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                        <h4><?php echo e(__('messages.add_new_product')); ?></h4>
                 </div>
        </div>
        <form action="" method="post" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>

            <div class="custom-file-container" data-upload-id="myFirstImage">
                <label><?php echo e(__('messages.upload')); ?> (<?php echo e(__('messages.multi_images')); ?>) <a href="javascript:void(0)" class="custom-file-container__image-clear" title="Clear Image">x</a></label>
                <label class="custom-file-container__custom-file" >
                    <input type="file" multiple required name="image[]" class="custom-file-container__custom-file__custom-file-input" accept="image/*">
                    <input type="hidden" name="MAX_FILE_SIZE" value="10485760" />
                    <span class="custom-file-container__custom-file__custom-file-control"></span>
                </label>
                <div class="custom-file-container__image-preview"></div>
            </div>            
            <div class="form-group mb-4">
                <label for="title"><?php echo e(__('messages.title')); ?></label>
                <input required type="text" name="title" class="form-control" id="title" placeholder="<?php echo e(__('messages.title')); ?>" value="" >
            </div>
            <div class="form-group mb-4">
                <label for="category"><?php echo e(__('messages.category')); ?></label>
                <select required name="category_id" class="selectpicker mb-4" data-width="100%">
                        <option selected disabled ><?php echo e(__('messages.select')); ?></option>
                    <?php $__currentLoopData = $data['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" > <?php echo e($category->title_ar); ?> </option>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>                
            </div>            
            <div class="form-group mb-4">
                <label for="description"><?php echo e(__('messages.description')); ?></label>
                <textarea required="" name="description" class="form-control" id="description" rows="5"></textarea>
            </div>            
            
            <input type="submit" value="<?php echo e(__('messages.submit')); ?>" class="btn btn-primary">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/aldorah.u-smart.co/resources/views/admin/product_form.blade.php ENDPATH**/ ?>