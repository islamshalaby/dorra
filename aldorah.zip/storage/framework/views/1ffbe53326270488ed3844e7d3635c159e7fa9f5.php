<?php $__env->startSection('title' , 'Admin Panel User Details'); ?>

<?php $__env->startSection('content'); ?>

        <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.contact_us_details')); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table class="table table-bordered mb-4">
                    <tbody>
                        <tr>
                            <td class="label-table" > <?php echo e(__('messages.phone')); ?></td>
                            <td><?php echo e($data['contact_us']['phone']); ?></td>
                        </tr>
                        <tr>
                            <td class="label-table" > <?php echo e(__('messages.message')); ?></td>
                            <td><?php echo e($data['contact_us']['message']); ?></td>
                        </tr> 
                        <tr>
                            <td class="label-table" > <?php echo e(__('messages.date')); ?></td>
                            <td><?php echo e($data['contact_us']['created_at']); ?></td>
                        </tr> 
                    </tbody>
                </table>
            </div>
        </div>
    </div>  

<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usmart006/Projects/medlaw-backend/resources/views/admin/contact_us_details.blade.php ENDPATH**/ ?>