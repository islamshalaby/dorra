<?php $__env->startSection('title' , 'Aldora Dashboard Users'); ?>

<?php $__env->startSection('content'); ?>
    <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.show_orders')); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table id="html5-extension" class="table table-hover non-hover" style="width:100%">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th><?php echo e(__('messages.user_name')); ?></th>
                            <th><?php echo e(__('messages.user_phone')); ?></th>
                            <th class="text-center" ><?php echo e(__('messages.date')); ?></th>
                            <th class="text-center"><?php echo e(__('messages.details')); ?></th>
                            <?php if(Auth::user()->delete_data): ?> 
                                <th class="text-center"><?php echo e(__('messages.delete')); ?></th>
                            <?php endif; ?>    
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $data['orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="<?php echo e($order->seen == 0 ? 'unread' : ''); ?>" >
                                <td><?=$i;?></td>
                                <td><?php echo e($order->name); ?></td>
                                <td><?php echo e($order->phone); ?></td>
                                <td><?php echo e($order->created_at); ?></td>
                                <td class="text-center blue-color"><a href="/admin-panel/orders/details/<?php echo e($order->id); ?>" ><i class="far fa-eye"></i></a></td>
                                <?php if(Auth::user()->update_data): ?> 
                                    <td class="text-center blue-color" ><a onclick="return confirm('Are you sure you want to delete this item?');" href="/admin-panel/orders/delete/<?php echo e($order->id); ?>" ><i class="far fa-trash-alt"></i></a></td>
                                <?php endif; ?>
                                <?php $i++; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        
    </div>  
<?php $__env->stopSection(); ?>  


<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/aldorah.u-smart.co/resources/views/admin/orders.blade.php ENDPATH**/ ?>