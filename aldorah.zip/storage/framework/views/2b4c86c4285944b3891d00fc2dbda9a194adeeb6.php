<?php $__env->startSection('title' , 'Dashboard Banks'); ?>

<?php $__env->startSection('content'); ?>
    <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.show_banks')); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table id="html5-extension" class="table table-hover non-hover" style="width:100%">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th><?php echo e(__('messages.bank_name')); ?></th>                            
                            <?php if(Auth::user()->update_data): ?> 
                                <th class="text-center"><?php echo e(__('messages.edit')); ?></th>
                            <?php endif; ?>
                            <?php if(Auth::user()->delete_data): ?> 
                                <th class="text-center"><?php echo e(__('messages.delete')); ?></th>
                            <?php endif; ?>                                
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $data['banks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?=$i;?></td>
                                <td><?php echo e($bank->bank_name); ?></td>
                                <?php if(Auth::user()->update_data): ?> 
                                    <td class="text-center blue-color" ><a href="/admin-panel/banks/edit/<?php echo e($bank->id); ?>" ><i class="far fa-edit"></i></a></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->delete_data): ?> 
                                    <td class="text-center blue-color" ><a onclick="return confirm('Are you sure you want to delete this item?');" href="/admin-panel/banks/delete/<?php echo e($bank->id); ?>" ><i class="far fa-trash-alt"></i></a></td>
                                <?php endif; ?>                                
                                <?php $i++; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        
    </div>  
<?php $__env->stopSection(); ?>  


<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/aldorah.u-smart.co/resources/views/admin/banks.blade.php ENDPATH**/ ?>