<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Med&Law - Terms and Conditions APP</title>
    <link rel="stylesheet" type="text/css" href="https://www.fontstatic.com/f=zahra-bold" />
    <link rel="stylesheet" href="/css/webview.css">
    <style>
        .editor-toolbar , .editor-preview-side , .CodeMirror , .editor-statusbar{
            display : none;
        } 
        .text-container .title{
            color: #924485;
        }
        body{
            direction : rtl;
        }
        .text-container .text{
            font-size : 20px;
        }    
    </style>
</head>
<body>
    <div class="container">

        <div class="text-container">
            <h1 class="title" ><?php echo e($title); ?></h1>
            <p class="text" ></p>
        <textarea style="display: none" id="editor1" ><?=$text?></textarea>
        </div>
    </div>
    <script src="/admin/assets/js/libs/jquery-3.1.1.min.js"></script>
    <script src="/admin/plugins/editors/markdown/simplemde.min.js"></script>
    <script src="/admin/plugins/editors/markdown/custom-markdown.js"></script>

    <script>
        var demo1 = new SimpleMDE({ element: document.getElementById("editor1") });            
        var value1 = demo1.value();  
        var demo1value = demo1.options.previewRender(value1);
        $(".text").html(demo1value);
    </script>

</body>
</html><?php /**PATH /home/usmart006/Projects/aldorah-dashboard/resources/views/webview/termsandconditions.blade.php ENDPATH**/ ?>