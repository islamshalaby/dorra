<?php $__env->startSection('title' , 'Home title'); ?>

<?php $__env->startSection('container'); ?>
    <p>this is container</p>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usmart006/Projects/medandlaw/resources/views/admin/home.blade.php ENDPATH**/ ?>