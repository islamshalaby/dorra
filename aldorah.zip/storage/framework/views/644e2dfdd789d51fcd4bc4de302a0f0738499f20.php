<?php $__env->startSection('title' , 'Admin Panel AboutApp'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Setting</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usmart006/Projects/medandlaw/resources/views/admin/setting.blade.php ENDPATH**/ ?>