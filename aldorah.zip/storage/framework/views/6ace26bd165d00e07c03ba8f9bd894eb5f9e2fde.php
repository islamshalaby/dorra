<?php $__env->startSection('title' , 'Admin Panel Add New Bank'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                        <h4><?php echo e(__('messages.edit_bank')); ?></h4>
                 </div>
        </div>
        <form action="" method="post" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <div class="form-group mb-4">
                <label for="title_ar"><?php echo e(__('messages.bank_name')); ?></label>
                <input required type="text" name="bank_name" class="form-control" id="title_ar" placeholder="<?php echo e(__('messages.bank_name')); ?>" value="<?php echo e($data['bank']['bank_name']); ?>" >
            </div>
            <input type="submit" value="<?php echo e(__('messages.submit')); ?>" class="btn btn-primary">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/aldorah.u-smart.co/resources/views/admin/bank_edit.blade.php ENDPATH**/ ?>