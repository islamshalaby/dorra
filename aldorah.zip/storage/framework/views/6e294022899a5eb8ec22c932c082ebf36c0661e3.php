<?php $__env->startSection('title' , 'Admin Panel Add New User'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-lg-12 col-12 layout-spacing">
    <div class="statbox widget box box-shadow">
        <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.update_profile')); ?></h4>
             </div>
    </div>
    
    <?php if(session('status')): ?>
        <div class="alert alert-danger mb-4" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">x</button>
            <strong>Error!</strong> <?php echo e(session('status')); ?> </button>
        </div> 
    <?php endif; ?>

    <form method="post" action="" >
     <?php echo csrf_field(); ?>
    <div class="form-group mb-4">
        <label for="name"><?php echo e(__('messages.manager_name')); ?></label>
        <input required type="text" name="name" class="form-control" id="name" placeholder="<?php echo e(__('messages.manager_name')); ?>" value="<?php echo e($data['name']); ?>" >
    </div>

    <div class="form-group mb-4">
        <label for="email"><?php echo e(__('messages.manager_email')); ?></label>
        <input required type="Email" class="form-control" id="email" name="email" placeholder="<?php echo e(__('messages.manager_email')); ?>" value="<?php echo e($data['email']); ?>" >
    </div>
    <div class="form-group mb-4">
        <label for="password"><?php echo e(__('messages.password')); ?></label>
        <input  type="password" class="form-control" id="password" name="password" placeholder="<?php echo e(__('messages.password')); ?>" value="" >
    </div>
    <br>
    <input type="submit" value="<?php echo e(__('messages.submit')); ?>" class="btn btn-primary">
</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usmart006/Projects/Aldora/resources/views/admin/profile.blade.php ENDPATH**/ ?>