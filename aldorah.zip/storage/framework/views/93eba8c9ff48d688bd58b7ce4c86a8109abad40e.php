<?php $__env->startSection('title' , 'Admin Panel Edit Product'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                        <h4><?php echo e(__('messages.product_edit')); ?></h4>
                 </div>
        </div>
        <form action="" method="post" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <?php if( count($data['product_images']) > 0 ): ?>
            <div class="form-group mb-4">
                <label for=""><?php echo e(__('messages.current_images')); ?></label><br>
                <div  class="row" >
                <?php $__currentLoopData = $data['product_images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12" >
                        <img src="https://res.cloudinary.com/dtmkwyhpn/image/upload/w_100,q_100/v1582799430/<?php echo e($product_image->image); ?>"  />    
                        <a onclick="return confirm('Are you sure you want to delete this item?');" href="/admin-panel/products/images/delete/<?php echo e($product_image->id); ?>" ><i class="far fa-trash-alt"></i></a>                    
                    </div>                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
                </div>
            </div>
            <?php endif; ?>
            <div class="custom-file-container" data-upload-id="myFirstImage">
                <label><?php echo e(__('messages.change_image')); ?> (<?php echo e(__('messages.multi_images')); ?>) <a href="javascript:void(0)" class="custom-file-container__image-clear" title="Clear Image">x</a></label>
                <label class="custom-file-container__custom-file" >
                    <input multiple type="file" name="image[]" class="custom-file-container__custom-file__custom-file-input" accept="image/*">
                    <input type="hidden" name="MAX_FILE_SIZE" value="10485760" />
                    <span class="custom-file-container__custom-file__custom-file-control"></span>
                </label>
                <div class="custom-file-container__image-preview"></div>
            </div>
            <div class="form-group mb-4">
                <label for="title"><?php echo e(__('messages.title')); ?></label>
                <input required type="text" name="title" class="form-control" id="title" placeholder="<?php echo e(__('messages.title')); ?>" value="<?php echo e($data['product']['title']); ?>" >
            </div>

            <div class="form-group mb-4" style="margin-bottom : 0 !important" >
                <label for="category"><?php echo e(__('messages.category')); ?></label>
                <select name="category_id" class="selectpicker mb-4" data-width="100%">
                    <option selected disabled ><?php echo e(__('messages.select')); ?></option>
                    <?php $__currentLoopData = $data['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($data['product']['category_id'] == $category->id ? 'selected' : ''); ?> value="<?php echo e($category->id); ?>" ><?php echo e($category->title_ar); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
                </select>                
            </div>

            <div class="form-group mb-4">
                <label for="description"><?php echo e(__('messages.description')); ?></label>
                <textarea required="" name="description" class="form-control" id="description" rows="5"><?php echo e($data['product']['description']); ?></textarea>
            </div> 

            <input type="submit" value="<?php echo e(__('messages.submit')); ?>" class="btn btn-primary">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usmart006/Projects/Aldora Git/aldorah-dashboard/resources/views/admin/product_edit.blade.php ENDPATH**/ ?>