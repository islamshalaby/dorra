<?php $__env->startSection('title' , 'Admin Panel Ad Details'); ?>

<?php $__env->startSection('content'); ?>
        <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.ad_details')); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table class="table table-bordered mb-4">
                    <tbody>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.image')); ?></td>
                                <td>
                                    <img src="https://res.cloudinary.com/dtmkwyhpn/image/upload/w_100,q_100/v1582799430/<?php echo e($data['ad']['image']); ?>"  />
                                </td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.link')); ?> </td>
                                <td>
                                    <a target="_blank" href="<?php echo e($data['ad']['content']); ?>" >
                                        <?php echo e($data['ad']['content']); ?>

                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.adtype')); ?> </td>
                                <td>
                                    <?php if($data['ad']['type'] == 'inside'): ?>
                                        <?php echo e(__('messages.insideapp')); ?>

                                    <?php else: ?>
                                        <?php echo e(__('messages.outsideapp')); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>                                                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>  
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/aldorah.u-smart.co/resources/views/admin/ad_details.blade.php ENDPATH**/ ?>