<?php $__env->startSection('title' , 'Admin Panel Add New Product'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                        <h4><?php echo e(__('messages.add_new_account_number')); ?></h4>
                 </div>
        </div>
        <form action="" method="post" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <div class="form-group mb-4">
                <label for="account_name"><?php echo e(__('messages.account_name')); ?></label>
                <input required type="text" name="account_name" class="form-control" id="account_name" placeholder="<?php echo e(__('messages.account_name')); ?>" value="" >
            </div>
            <div class="form-group mb-4">
                <label for="account_type"><?php echo e(__('messages.account_type')); ?></label>
                <input  type="text" name="account_type" class="form-control" id="account_type" placeholder="<?php echo e(__('messages.account_type')); ?>" value="" >
            </div>
            <div class="form-group mb-4">
                <label for="account_number"><?php echo e(__('messages.account_number')); ?></label>
                <input required  type="text" name="account_number" class="form-control" id="account_number" placeholder="<?php echo e(__('messages.account_number')); ?>" value="" >
            </div>
            <div class="form-group mb-4">
                <label for="iban"><?php echo e(__('messages.iban')); ?></label>
                <input   type="text" name="iban" class="form-control" id="iban" placeholder="<?php echo e(__('messages.iban')); ?>" value="" >
            </div>
            
            <div class="form-group mb-4">
                <label for="bank"><?php echo e(__('messages.select_bank')); ?></label>
                <select required name="bank_id" class="selectpicker mb-4" data-width="100%">
                        <option selected disabled ><?php echo e(__('messages.select')); ?></option>
                    <?php $__currentLoopData = $data['banks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($bank->id); ?>" > <?php echo e($bank->bank_name); ?> </option>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>                
            </div>           
            
            <input type="submit" value="<?php echo e(__('messages.submit')); ?>" class="btn btn-primary">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/aldorah.u-smart.co/resources/views/admin/accounts_numbers_form.blade.php ENDPATH**/ ?>