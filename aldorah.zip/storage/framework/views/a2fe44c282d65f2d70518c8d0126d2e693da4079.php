<?php $__env->startSection('title' , 'Med&Law Dashboard Users Section'); ?>

<?php $__env->startSection('content'); ?>
    <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.show_users')); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table class="table table-bordered mb-4">
                    <thead>
                        <tr>
                            <th><?php echo e(__('messages.user_name')); ?></th>
                            <th><?php echo e(__('messages.user_phone')); ?></th>
                            <th><?php echo e(__('messages.user_email')); ?></th>
                            <th class="text-center"><?php echo e(__('messages.details')); ?></th>
                            <th class="text-center"><?php echo e(__('messages.edit')); ?></th>                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->phone); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td class="text-center blue-color"><a href="/admin-panel/users/details/<?php echo e($user->id); ?>" ><i class="far fa-eye"></i></a></td>
                                <td class="text-center blue-color" ><a href="/admin-panel/users/edit/<?php echo e($user->id); ?>" ><i class="far fa-edit"></i></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="paginating-container pagination-solid">
            <ul class="pagination">
                <li class="prev"><a href="<?php echo e($data['users']->previousPageUrl()); ?>">Prev</a></li>
                <?php for($i = 1 ; $i <= $data['users']->lastPage(); $i++ ): ?>
                    <li class="<?php echo e($data['users']->currentPage() == $i ? "active" : ''); ?>"><a href="/admin-panel/users/show?page=<?php echo e($i); ?>"><?php echo e($i); ?></a></li>               
                <?php endfor; ?>
                <li class="next"><a href="<?php echo e($data['users']->nextPageUrl()); ?>">Next</a></li>
            </ul>
        </div>  
    </div>  
<?php $__env->stopSection(); ?>  


<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usmart006/Projects/medandlaw/resources/views/admin/users.blade.php ENDPATH**/ ?>