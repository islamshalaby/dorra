<?php $__env->startSection('title' , 'Admin Panel User Details'); ?>

<?php $__env->startSection('content'); ?>

        <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.donation_details')); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table class="table table-bordered mb-4">
                    <tbody>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.user_name')); ?> </td>
                                <td>
                                    <?php echo e($data['donation']['name']); ?>

                                </td>
                            </tr>                    
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.user_phone')); ?> </td>
                                <td>
                                    <?php echo e($data['donation']['phone']); ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.donation_description')); ?> </td>
                                <td>
                                    <?php echo e($data['donation']['description']); ?>

                                </td>
                            </tr>                    
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.images')); ?> </td>
                                <td>
                                    <?php $__currentLoopData = $data['donation']['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a target="_blank" href="https://res.cloudinary.com/dtmkwyhpn/image/upload/v1582799430/<?php echo e($image['image']); ?>" >
                                         <img src="https://res.cloudinary.com/dtmkwyhpn/image/upload/w_150,q_100/v1582799430/<?php echo e($image['image']); ?>" > &nbsp;  
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.donation_categories')); ?> </td>
                                <td>
                                    <?php $__currentLoopData = $data['donation']['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span><?php echo e($category['title_ar']); ?> ,</span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.address')); ?> </td>
                                <td><?php echo e($data['donation']['address']); ?></td>
                            </tr>                            
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.location')); ?> </td>
                                <td>
                                    <a style="color: blue" target="_blank" href=<?php echo e("https://www.google.com/maps/@".$data['donation']['latitude'].",".$data['donation']['longitude'].",18z"); ?> ><?php echo e(__('messages.open_map')); ?></a>
                                </td>
                            </tr>

                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.date')); ?> </td>
                                <td>
                                    <?php echo e($data['donation']['created_at']); ?>

                                </td>
                            </tr>                    
                    </tbody>
                </table>
            </div>

        </div>
    </div>  

<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/aldorah.u-smart.co/resources/views/admin/donation_details.blade.php ENDPATH**/ ?>