<?php $__env->startSection('title' , 'Admin Panel User Details'); ?>

<?php $__env->startSection('content'); ?>

        <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.order_details')); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table class="table table-bordered mb-4">
                    <tbody>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.product_name')); ?> </td>
                                <td>
                                    <a style="color: blue" target="_blank" href=<?php echo e("/admin-panel/products/edit/".$data['order']['product']['id']); ?> ><?php echo e($data['order']['product']['title']); ?></a>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.image')); ?> </td>
                                <td>
                                    <?php if($data['order']['product']['image']): ?>
                                        <img style="max-height: 100px" src="https://res.cloudinary.com/dtmkwyhpn/image/upload/w_100,q_100/v1582799430/<?php echo e($data['order']['product']['image']); ?>"  />
                                    <?php else: ?>
                                        <span> No Image </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                                                
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.user_name')); ?></td>
                                <td><?php echo e($data['order']['name']); ?></td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.user_phone')); ?> </td>
                                <td><?php echo e($data['order']['phone']); ?></td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.date_of_birth')); ?> </td>
                                <td><?php echo e($data['order']['birth_date']); ?></td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.gender')); ?> </td>
                                <td>
                                    <?php echo e($data['order']['gender'] == 1 ? __('messages.male') : __('messages.female')); ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.salary')); ?> </td>
                                <td><?php echo e($data['order']['salary'].' '. __('messages.riyal')); ?></td>
                            </tr>                                                        
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.family_count')); ?> </td>
                                <td><?php echo e($data['order']['family_count'].' '. __('messages.person')); ?></td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.social_status')); ?> </td>
                                <td>
                                    <?php switch($data['order']['social_status']):
                                        case (1): ?>
                                            <?php echo e(__('messages.single')); ?>

                                            <?php break; ?>

                                        <?php case (2): ?>
                                            <?php echo e(__('messages.married')); ?>

                                            <?php break; ?>

                                        <?php case (3): ?>
                                            <?php echo e(__('messages.divorced')); ?>

                                            <?php break; ?>

                                        <?php case (4): ?>
                                            <?php echo e(__('messages.widow')); ?>

                                            <?php break; ?>
                                    <?php endswitch; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.address')); ?> </td>
                                <td><?php echo e($data['order']['address']); ?></td>
                            </tr>                            
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.location')); ?> </td>
                                <td>
                                    <a style="color: blue" target="_blank" href=<?php echo e("https://www.google.com/maps/@".$data['order']['latitude'].",".$data['order']['longitude'].",18z"); ?> ><?php echo e(__('messages.open_map')); ?></a>
                                </td>
                            </tr>
                            
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.date')); ?> </td>
                                <td><?php echo e($data['order']['created_at']); ?></td>
                            </tr>
                    </tbody>
                </table>
            </div>

        </div>
    </div>  

<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usmart006/Projects/Aldora Git/aldorah-dashboard/resources/views/admin/order_details.blade.php ENDPATH**/ ?>