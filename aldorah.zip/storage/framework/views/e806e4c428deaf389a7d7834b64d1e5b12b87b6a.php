<?php $__env->startSection('title' , 'Admin Panel Counts'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-lg-12 col-12 layout-spacing">
    <div class="statbox widget box box-shadow">
        <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.counts')); ?></h4>
             </div>
    </div>
    <form method="post" action="" enctype="multipart/form-data" >
        <?php echo csrf_field(); ?>
         <div class="form-group mb-4">
            <label for="beneficiaries_count"><?php echo e(__('messages.beneficiaries_count')); ?></label>
            <input required type="number" name="beneficiaries_count" class="form-control" id="beneficiaries_count" placeholder="<?php echo e(__('messages.beneficiaries_count')); ?>" value="<?php echo e($data['count']['user']); ?>" >
        </div>       
         <div class="form-group mb-4">
            <label for="services_count"><?php echo e(__('messages.services_count')); ?></label>
            <input required type="number" name="services_count" class="form-control" id="services_count" placeholder="<?php echo e(__('messages.services_count')); ?>" value="<?php echo e($data['count']['service']); ?>" >
        </div>       
         <div class="form-group mb-4">
            <label for="family"><?php echo e(__('messages.family')); ?></label>
            <input required type="number" name="family" class="form-control" id="family" placeholder="<?php echo e(__('messages.family')); ?>" value="<?php echo e($data['count']['family']); ?>" >
        </div>       
         <div class="form-group mb-4">
            <label for="initiative"><?php echo e(__('messages.initiative')); ?></label>
            <input required type="number" name="initiative" class="form-control" id="initiative" placeholder="<?php echo e(__('messages.initiative')); ?>" value="<?php echo e($data['count']['initiative']); ?>" >
        </div>       
        <input type="submit" value="<?php echo e(__('messages.submit')); ?>" class="btn btn-primary">
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usmart006/Projects/aldorah-dashboard/resources/views/admin/counts.blade.php ENDPATH**/ ?>