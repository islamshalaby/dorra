<?php $__env->startSection('title' , 'Admin Panel Add New Service'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                        <h4><?php echo e(__('messages.add_new_service')); ?></h4>
                 </div>
        </div>
        <form action="" method="post" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <div class="custom-file-container" data-upload-id="myFirstImage">
                <label><?php echo e(__('messages.upload')); ?> (<?php echo e(__('messages.single_image')); ?>) <a href="javascript:void(0)" class="custom-file-container__image-clear" title="Clear Image">x</a></label>
                <label class="custom-file-container__custom-file" >
                    <input type="file" required name="image" class="custom-file-container__custom-file__custom-file-input" accept="image/*">
                    <input type="hidden" name="MAX_FILE_SIZE" value="10485760" />
                    <span class="custom-file-container__custom-file__custom-file-control"></span>
                </label>
                <div class="custom-file-container__image-preview"></div>
            </div>            
            <div class="form-group mb-4">
                <label for="title"><?php echo e(__('messages.title')); ?></label>
                <input maxlength="25" required type="text" name="title" class="form-control title_news" id="title" placeholder="<?php echo e(__('messages.title')); ?>" value="" >
            </div>
            <div class="form-group mb-4">
                <label for="small_description"><?php echo e(__('messages.small_description')); ?></label>
                <input maxlength="50" required type="text" name="small_description" class="form-control small_description_news" id="small_description" placeholder="<?php echo e(__('messages.small_description')); ?>" value="" >
            </div>
            <div class="form-group mb-4 arabic-direction">
                <label for="news_editor"><?php echo e(__('messages.description')); ?></label>
                <textarea id="news_editor" name="description" class="form-control"  rows="5"></textarea>
            </div>                
            <input type="submit" value="<?php echo e(__('messages.submit')); ?>" class="btn btn-primary">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usmart006/Projects/aldorah-dashboard/resources/views/admin/services_form.blade.php ENDPATH**/ ?>