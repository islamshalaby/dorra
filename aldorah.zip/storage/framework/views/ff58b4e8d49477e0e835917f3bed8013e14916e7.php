<?php $__env->startSection('title' , 'Admin Panel Settings'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-lg-12 col-12 layout-spacing">
    <div class="statbox widget box box-shadow">
        <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.setting')); ?></h4>
             </div>
    </div>
    <form method="post" action="" enctype="multipart/form-data" >
        <?php echo csrf_field(); ?>
         

         

         <div class="form-group mb-4">
            <label for="app_name_en"><?php echo e(__('messages.app_name_en')); ?></label>
            <input required type="text" name="app_name_en" class="form-control" id="app_name_en" placeholder="<?php echo e(__('messages.app_name_en')); ?>" value="<?php echo e($data['setting']['app_name_en']); ?>" >
        </div>
         <div class="form-group mb-4">
            <label for="app_name_ar"><?php echo e(__('messages.app_name_ar')); ?></label>
            <input required type="text" name="app_name_ar" class="form-control" id="app_name_ar" placeholder="<?php echo e(__('messages.app_name_ar')); ?>" value="<?php echo e($data['setting']['app_name_ar']); ?>" >
        </div>
         <div class="form-group mb-4">
            <label for="email"><?php echo e(__('messages.email')); ?></label>
            <input required type="email" name="email" class="form-control" id="email" placeholder="<?php echo e(__('messages.email')); ?>" value="<?php echo e($data['setting']['email']); ?>" >
        </div>
        <div class="form-group mb-4">
            <label for="phone"><?php echo e(__('messages.phone')); ?></label>
            <input required type="phone" name="phone" class="form-control" id="phone" placeholder="<?php echo e(__('messages.phone')); ?>" value="<?php echo e($data['setting']['phone']); ?>" >
        </div>
        <div class="form-group mb-4">
            <label for="app_phone"><?php echo e(__('messages.support_phone')); ?></label>
            <input required type="phone" name="app_phone" class="form-control" id="app_phone" placeholder="<?php echo e(__('messages.support_phone')); ?>" value="<?php echo e($data['setting']['app_phone']); ?>" >
        </div>
        <div class="form-group mb-4">
            <label for="address_en"><?php echo e(__('messages.address_en')); ?></label>
            <input  type="text" name="address_en" class="form-control" id="address_en" placeholder="<?php echo e(__('messages.address_en')); ?>" value="<?php echo e($data['setting']['address_en']); ?>" >
        </div>
        <div class="form-group mb-4">
            <label for="address_ar"><?php echo e(__('messages.address_ar')); ?></label>
            <input  type="text" name="address_ar" class="form-control" id="address_ar" placeholder="<?php echo e(__('messages.address_ar')); ?>" value="<?php echo e($data['setting']['address_ar']); ?>" >
        </div>
        <div class="form-group mb-4">
            <label for="facebook"><?php echo e(__('messages.facebook')); ?></label>
            <input  type="text" name="facebook" class="form-control" id="facebook" placeholder="<?php echo e(__('messages.facebook')); ?>" value="<?php echo e($data['setting']['facebook']); ?>" >
        </div>
        <div class="form-group mb-4">
            <label for="youtube"><?php echo e(__('messages.youtube')); ?></label>
            <input  type="text" name="youtube" class="form-control" id="youtube" placeholder="<?php echo e(__('messages.youtube')); ?>" value="<?php echo e($data['setting']['youtube']); ?>" >
        </div>
        <div class="form-group mb-4">
            <label for="twitter"><?php echo e(__('messages.twitter')); ?></label>
            <input  type="text" name="twitter" class="form-control" id="twitter" placeholder="<?php echo e(__('messages.twitter')); ?>" value="<?php echo e($data['setting']['twitter']); ?>" >
        </div>
        <div class="form-group mb-4">
            <label for="instegram"><?php echo e(__('messages.instegram')); ?></label>
            <input  type="text" name="instegram" class="form-control" id="instegram" placeholder="<?php echo e(__('messages.instegram')); ?>" value="<?php echo e($data['setting']['instegram']); ?>" >
        </div>
        <div class="form-group mb-4">
            <label for="snap_chat"><?php echo e(__('messages.snap_chat')); ?></label>
            <input  type="text" name="snap_chat" class="form-control" id="snap_chat" placeholder="<?php echo e(__('messages.snap_chat')); ?>" value="<?php echo e($data['setting']['snap_chat']); ?>" >
        </div>
        <div class="form-group mb-4">
            <label for="map_url"><?php echo e(__('messages.map_url')); ?></label>
            <input  type="text" name="map_url" class="form-control" id="map_url" placeholder="<?php echo e(__('messages.map_url')); ?>" value="<?php echo e($data['setting']['map_url']); ?>" >
        </div>
        <div class="form-group mb-4">
            <input  type="hidden" name="latitude" class="form-control"  value="<?php echo e($data['setting']['latitude']); ?>" >
        </div>
        <div class="form-group mb-4">
            <input  type="hidden" name="longitude" class="form-control" value="<?php echo e($data['setting']['longitude']); ?>" >
        </div>        
            <input type="submit" value="<?php echo e(__('messages.submit')); ?>" class="btn btn-primary">
        
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usmart006/Projects/Aldora Git/aldorah-dashboard/resources/views/admin/setting.blade.php ENDPATH**/ ?>